package com.white_tree.service;

import com.white_tree.pojo.LoginInfo;
import com.white_tree.pojo.User;

import java.util.List;

public interface UserService {
    List<User> findAll();

    LoginInfo login(User user);
}

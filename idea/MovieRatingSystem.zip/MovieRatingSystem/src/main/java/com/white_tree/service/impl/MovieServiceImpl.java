package com.white_tree.service.impl;

import com.white_tree.mapper.MovieMapper;
import com.white_tree.pojo.Movie;
import com.white_tree.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieServiceImpl implements MovieService {

    @Autowired
    private MovieMapper movieMapper;

    @Override
    public List<Movie> findAll() {

        return movieMapper.findAll();
    }
}

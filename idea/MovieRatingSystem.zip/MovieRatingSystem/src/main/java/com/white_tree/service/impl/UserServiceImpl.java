package com.white_tree.service.impl;

import com.white_tree.mapper.UserMapper;
import com.white_tree.pojo.LoginInfo;
import com.white_tree.pojo.User;
import com.white_tree.service.UserService;
import com.white_tree.utils.JwtUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;

    @Override
    public List<User> findAll() {
        return userMapper.findAll();
    }

    @Override
    public LoginInfo login(User user) {
        // 根据用户名和密码查询用户
        User u = userMapper.selectByUsernameAndPassword(user); // 使用注入的实例调用
        if (u != null){
            log.info("登录成功，用户信息：{}", u);
            //生成jwt令牌
            Map<String, Object> claims = new HashMap<>();
            claims.put("userId", u.getUserID());
            claims.put("username", u.getUsername());
            String jwt = JwtUtils.generateToken(claims);
            LoginInfo info = new LoginInfo(u.getUserID(), u.getUsername(), u.getPassword(), jwt);
            return info;
        }
        return null;
    }

}

package com.white_tree.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;
import java.util.Map;

/**
 * JWT工具类 - 提供令牌生成和解析功能
 */
public class JwtUtils {

    // 签名密钥（Base64编码的"white_tree"字符串）
    private static final String SECRET_KEY = "d2hpdGVfdHJlZQ==";

    // 令牌有效期（12小时）
    private static final long EXPIRATION_TIME = 12 * 3600 * 1000;

    /**
     * 生成JWT令牌
     * @param claims 令牌中存储的声明信息
     * @return 生成的JWT字符串
     */
    public static String generateToken(Map<String, Object> claims) {
        return Jwts.builder()
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY) // 签名算法和密钥
                .addClaims(claims)                            // 添加自定义声明
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME)) // 设置过期时间
                .compact();                                    // 生成令牌
    }

    /**
     * 解析JWT令牌
     * @param token 待解析的JWT字符串
     * @return 解析后的声明体
     * @throws io.jsonwebtoken.JwtException 当令牌无效或过期时抛出异常
     */
    public static Claims parseToken(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)     // 设置签名密钥
                .parseClaimsJws(token)         // 解析令牌
                .getBody();                    // 获取声明体
    }
}
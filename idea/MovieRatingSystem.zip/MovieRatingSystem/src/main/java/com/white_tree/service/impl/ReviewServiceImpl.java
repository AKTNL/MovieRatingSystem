package com.white_tree.service.impl;

import com.white_tree.mapper.ReviewMapper;
import com.white_tree.pojo.Review;
import com.white_tree.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewServiceImpl implements ReviewService {
    @Autowired
    private ReviewMapper reviewMapper;

    @Override
    public List<Review> findAll() {
        return reviewMapper.findAll();
    }
}

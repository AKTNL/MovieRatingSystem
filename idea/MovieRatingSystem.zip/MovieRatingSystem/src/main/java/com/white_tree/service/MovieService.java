package com.white_tree.service;

import com.white_tree.pojo.Movie;

import java.util.List;

public interface MovieService {

    List<Movie> findAll();
}

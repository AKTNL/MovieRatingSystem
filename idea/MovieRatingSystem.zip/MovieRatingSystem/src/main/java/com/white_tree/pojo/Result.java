package com.white_tree.pojo;

import lombok.Data;

@Data
public class Result {
    private Integer code; //0失败 1成功
    private String msg; //返回信息
    private Object data; //返回数据

    public static Result success(){
        Result  result = new Result();
        result.code = 1;
        result.msg = "success";
        return result;
    }

    public static Result success(Object data){
        Result  result = new Result();
        result.data = data;
        result.code = 1;
        result.msg = "success";
        return result;
    }

    public static Result error(String msg){
        Result  result = new Result();
        result.code = 0;
        result.msg = msg;
        return result;
    }

}

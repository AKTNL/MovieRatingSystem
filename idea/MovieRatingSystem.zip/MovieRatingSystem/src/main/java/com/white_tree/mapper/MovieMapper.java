package com.white_tree.mapper;

import com.white_tree.pojo.Movie;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface MovieMapper {

    //查询所有电影
    @Select("select * from movies")
    List<Movie> findAll();
}

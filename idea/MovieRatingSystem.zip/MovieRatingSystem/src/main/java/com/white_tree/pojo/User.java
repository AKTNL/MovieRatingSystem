package com.white_tree.pojo;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class User {
    private Integer UserID;
    private String Username;
    private String Password;
    private String Email;
    private LocalDateTime RegistrationDate;
    private String Role;

}

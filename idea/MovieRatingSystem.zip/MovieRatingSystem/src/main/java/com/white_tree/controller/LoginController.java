package com.white_tree.controller;

import com.white_tree.pojo.LoginInfo;
import com.white_tree.pojo.Result;
import com.white_tree.pojo.User;
import com.white_tree.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class LoginController {
    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public Result login(@RequestBody User user){
        log.info("用户登录：{}", user);
        LoginInfo info = userService.login(user);
        if (info != null){
            return Result.success(info);
        }else {
            return Result.error("用户名或密码错误");
        }
    }
}

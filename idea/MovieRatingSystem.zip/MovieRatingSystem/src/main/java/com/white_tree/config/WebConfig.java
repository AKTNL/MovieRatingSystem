package com.white_tree.config;

import com.white_tree.interceptor.DemoInterceptor;
import com.white_tree.interceptor.TokenInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

//配置类
@Configuration
public class WebConfig implements WebMvcConfigurer {

//    @Autowired
//    private  DemoInterceptor demoInterceptor;
//
//    @Autowired
//    private TokenInterceptor tokenInterceptor;
//
//    @Override
//    public void addInterceptors(InterceptorRegistry registry) {
//        // 添加拦截器,拦截所有请求
//        registry.addInterceptor(tokenInterceptor).addPathPatterns("/**");
//    }
}

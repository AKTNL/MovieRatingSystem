package com.white_tree.mapper;

import com.white_tree.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
@Mapper
public interface UserMapper {



    @Select("select * from users where role = 'user'")
    List<User> findAll();


    @Select("select * from users where username = #{username} and password = #{password}")
    User selectByUsernameAndPassword(User user);
}

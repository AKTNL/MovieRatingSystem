package com.white_tree.pojo;

import java.time.LocalDateTime;

public class Director {
    private int DirectorID;
    private String director_name;
    private String director_gender;
    private LocalDateTime director_birthdate;
    private String director_nationality;
}

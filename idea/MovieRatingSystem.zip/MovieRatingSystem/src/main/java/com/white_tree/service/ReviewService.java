package com.white_tree.service;

import com.white_tree.pojo.Review;

import java.util.List;

public interface ReviewService {
    List<Review> findAll();
}

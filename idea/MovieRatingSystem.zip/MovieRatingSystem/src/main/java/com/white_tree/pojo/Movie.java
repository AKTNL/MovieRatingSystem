package com.white_tree.pojo;

import lombok.Data;

@Data
public class Movie {
    private Integer MovieID;
    private String Title;
    private Integer ReleaseYear;
    private Integer Duration;
    private String Genre;
    private String Language;
    private String Country;
    private String Synopsis;
    private double Rating;

}

package com.white_tree.pojo;

import java.time.LocalDateTime;

public class Actor {
    private Integer ActorID;
    private String actor_name;
    private String actor_gender;
    private LocalDateTime actor_birthdate;
    private String actor_nationality;
}

package com.white_tree.mapper;

import com.white_tree.pojo.Review;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ReviewMapper {

    @Results({
            @Result(column = "Rating" , property = "review_rating")
    })
    @Select("select Comment, Rating, ReviewDate from reviews")
    List<Review> findAll();
}

package com.white_tree.pojo;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class Review {
    private Integer ReviewID;
    private Integer UserID;
    private Integer MovieID;
    private String comment;
    private double review_rating;
    private LocalDateTime ReviewDate;

}

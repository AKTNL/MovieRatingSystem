package com.white_tree.controller;

import com.white_tree.pojo.Result;
import com.white_tree.pojo.Review;
import com.white_tree.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ReviewController {
    @Autowired
    private ReviewService reviewService;

    @GetMapping("/reviews")
    public Result list(){
        List<Review> reviewList = reviewService.findAll();
        return Result.success(reviewList);
    }
}

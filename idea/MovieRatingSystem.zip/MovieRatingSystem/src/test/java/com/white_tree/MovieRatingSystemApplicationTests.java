package com.white_tree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieRatingSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
